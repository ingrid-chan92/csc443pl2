#!/bin/bash
python part4_k_plot.py
python part4_mem_cap_plot.py
python part4_filesize_plot.py
python part5_plot.py
